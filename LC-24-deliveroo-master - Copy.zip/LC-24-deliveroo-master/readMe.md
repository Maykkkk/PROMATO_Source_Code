# Responsive Food Ordering Website with HTML, CSS and JavaScript

![Responsive Food Ordering Website with HTML, CSS and JavaScript](https://raw.githubusercontent.com/wpcodevo/LC-24-deliveroo/setup/Delivery%20responsive%20website.jpg "Responsive Food Ordering Website with HTML, CSS and JavaScript")

The Figma file of the Responsive Food Ordering Website can be found on my [website](https://www.ziddah.com)
